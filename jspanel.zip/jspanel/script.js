$(document).ready(function(){
    $("button").on("click", function openPanel(){
        $.jsPanel({
            theme:         'bootstrap-default',
            headerTitle:   'bootstrap-default',
            content:       ' Hello',
            //footerToolbar: ftr,
            callback: function () {
                //$('.jsPanel-ftr', this).css({flexFlow: 'row-reverse'});
                this.content.css("padding", "15px");
            }
        });
    })


});

